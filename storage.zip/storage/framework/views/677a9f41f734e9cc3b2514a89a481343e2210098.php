
<?php $__env->startSection('main-content'); ?>
    <div class="section-title komponen container mt-5">
        <h3 class="pt-3 pb-3">Simulasi Rakit PC</h3>
    </div>

    <section class="container d-flex justify-content-between mb-5">
        <table class="table">
            <thead>
                <tr class="heading-table">
                    <th scope="col">Kategori Komponen</th>
                    <th scope="col">Nama Komponen</th>
                    <th scope="col">Harga</th>
                    <th scope="col">E-commerce</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th class="py-4 category">CPU</th>
                    <?php if(session('edit-cpus')): ?>
                        <td>
                        <div class="d-flex align-items-center komponen">
                            <div class="flex-shrink-0">
                                <img width="40px" src="<?php echo e(asset('storage/images/pc-components/cpu/'. session()->get('edit-cpus')->image)); ?>" alt="...">
                            </div>
                            <div class="nama-komponen">
                                <?php echo e(session()->get('edit-cpus')->name); ?>

                            </div>
                        </div>
                        </td>
                        <td class="py-4"><?php echo e(session()->get('edit-cpus')->formattedPrice); ?></td>
                        <td class="py-4 e-commerce">
                            <img src="<?php echo e(asset('images/keranjang/logo-tokped.png')); ?>" alt="">                   
                        </td>
                        <td class="py-4">
                            <form action="<?php echo e(route('hapusItemSimulasi','edit-cpus')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit"><iconify-icon icon="material-symbols:close" width="24" height="24"></iconify-icon></button>
                            </form>
                        </td>
                    <?php else: ?>    
                        <td>
                            <div class="d-flex align-items-center komponen py-2">
                                <form action="<?php echo e(url('/simulasi-rakit-pc/addComponent/cpus')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn add" type="submit"> + Add Item </button>
                                </form>
                            </div>
                        </td>
                        <td class="py-4"></td>
                        <td class="py-4"></td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th class="py-4 category">Motherboard</th>
                    <?php if(session('edit-motherboards')): ?>
                        <td>
                        <div class="d-flex align-items-center komponen">
                            <div class="flex-shrink-0">
                                <img width="40px" src="<?php echo e(asset('storage/images/pc-components/motherboard/'. session()->get('edit-motherboards')->image)); ?>" alt="...">
                            </div>
                            <div class="nama-komponen">
                                <?php echo e(session()->get('edit-motherboards')->name); ?>

                            </div>
                        </div>
                        </td>
                        <td class="py-4"><?php echo e(session()->get('edit-motherboards')->formattedPrice); ?></td>
                        <td class="py-4 e-commerce">
                            <img src="<?php echo e(asset('images/keranjang/logo-tokped.png')); ?>" alt="">                   
                        </td>
                        <td class="py-4">
                            <form action="<?php echo e(route('hapusItemSimulasi','edit-motherboards')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit"><iconify-icon icon="material-symbols:close" width="24" height="24"></iconify-icon></button>
                            </form>
                        </td>
                    <?php else: ?>    
                        <td>
                            <div class="d-flex align-items-center komponen py-2">
                                <form action="<?php echo e(url('/simulasi-rakit-pc/addComponent/motherboards')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="selectedCpuId" value="<?php echo e(session('edit-cpus') ? session()->get('edit-cpus')->id : ''); ?>" >
                                    <button class="btn add" type="submit" <?php echo e(session('edit-cpus') ? '' : 'disabled'); ?>>
                                        + Add Item
                                    </button>
                                </form>
                            </div>
                        </td>
                        <td class="py-4"></td>
                        <td class="py-4"></td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th class="py-4 category">Memory</th>
                    <?php if(session('edit-memories')): ?>
                        <td>
                        <div class="d-flex align-items-center komponen">
                            <div class="flex-shrink-0">
                                <img width="40px" src="<?php echo e(asset('storage/images/pc-components/memory/'. session()->get('edit-memories')->image)); ?>" alt="...">
                            </div>
                            <div class="nama-komponen">
                                <?php echo e(session()->get('edit-memories')->name); ?>

                            </div>
                        </div>
                        </td>
                        <td class="py-4"><?php echo e(session()->get('edit-memories')->formattedPrice); ?></td>
                        <td class="py-4 e-commerce">
                            <img src="<?php echo e(asset('images/keranjang/logo-tokped.png')); ?>" alt="">                   
                        </td>
                        <td class="py-4">
                            <form action="<?php echo e(route('hapusItemSimulasi','edit-memories')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit"><iconify-icon icon="material-symbols:close" width="24" height="24"></iconify-icon></button>
                            </form>
                        </td>
                    <?php else: ?>    
                        <td>
                            <div class="d-flex align-items-center komponen py-2">
                                <form action="<?php echo e(url('/simulasi-rakit-pc/addComponent/memories')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="selectedMoboId" value="<?php echo e(session('edit-motherboards') ? session()->get('edit-motherboards')->id : ''); ?>" >
                                    <button class="btn add" type="submit" <?php echo e(session('edit-motherboards') ? '' : 'disabled'); ?>>
                                        + Add Item
                                    </button>
                                </form>
                            </div>
                        </td>
                        <td class="py-4"></td>
                        <td class="py-4"></td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th class="py-4 category">Internal Storage</th>
                    <?php if(session('edit-internal_storages')): ?>
                        <td>
                        <div class="d-flex align-items-center komponen">
                            <div class="flex-shrink-0">
                                <img width="40px" src="<?php echo e(asset('storage/images/pc-components/internal-storage/'. session()->get('edit-internal_storages')->image)); ?>" alt="...">
                            </div>
                            <div class="nama-komponen">
                                <?php echo e(session()->get('edit-internal_storages')->name); ?>

                            </div>
                        </div>
                        </td>
                        <td class="py-4"><?php echo e(session()->get('edit-internal_storages')->formattedPrice); ?></td>
                        <td class="py-4 e-commerce">
                            <img src="<?php echo e(asset('images/keranjang/logo-tokped.png')); ?>" alt="">                   
                        </td>
                        <td class="py-4">
                            <form action="<?php echo e(route('hapusItemSimulasi','edit-internal_storages')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit"><iconify-icon icon="material-symbols:close" width="24" height="24"></iconify-icon></button>
                            </form>
                        </td>
                    <?php else: ?>    
                        <td>
                            <div class="d-flex align-items-center komponen py-2">
                                <form action="<?php echo e(url('/simulasi-rakit-pc/addComponent/internal_storages')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="selectedMemoryId" value="<?php echo e(session('edit-memories') ? session()->get('edit-memories')->id : ''); ?>" >
                                    <button class="btn add" type="submit" <?php echo e(session('edit-memories') ? '' : 'disabled'); ?>>
                                        + Add Item
                                    </button>
                                </form>
                            </div>
                        </td>
                        <td class="py-4"></td>
                        <td class="py-4"></td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th class="py-4 category">GPU</th>
                    <?php if(session('edit-gpus')): ?>
                        <td>
                        <div class="d-flex align-items-center komponen">
                            <div class="flex-shrink-0">
                                <img width="40px" src="<?php echo e(asset('storage/images/pc-components/gpu/'. session()->get('edit-gpus')->image)); ?>" alt="...">
                            </div>
                            <div class="nama-komponen">
                                <?php echo e(session()->get('edit-gpus')->name); ?>

                            </div>
                        </div>
                        </td>
                        <td class="py-4"><?php echo e(session()->get('edit-gpus')->formattedPrice); ?></td>
                        <td class="py-4 e-commerce">
                            <img src="<?php echo e(asset('images/keranjang/logo-tokped.png')); ?>" alt="">                   
                        </td>
                        <td class="py-4">
                            <form action="<?php echo e(route('hapusItemSimulasi','edit-gpus')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit"><iconify-icon icon="material-symbols:close" width="24" height="24"></iconify-icon></button>
                            </form>
                        </td>
                    <?php else: ?>    
                        <td>
                            <div class="d-flex align-items-center komponen py-2">
                                <form action="<?php echo e(url('/simulasi-rakit-pc/addComponent/gpus')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="selectedStorageId" value="<?php echo e(session('edit-internal_storages') ? session()->get('edit-internal_storages')->id : ''); ?>" >
                                    <button class="btn add" type="submit" <?php echo e(session('edit-internal_storages') ? '' : 'disabled'); ?>>
                                        + Add Item
                                    </button>
                                </form>
                            </div>
                        </td>
                        <td class="py-4"></td>
                        <td class="py-4"></td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th class="py-4 category">Casing</th>
                    <?php if(session('edit-cases')): ?>
                        <td>
                        <div class="d-flex align-items-center komponen">
                            <div class="flex-shrink-0">
                                <img width="40px" src="<?php echo e(asset('storage/images/pc-components/case/'. session()->get('edit-cases')->image)); ?>" alt="...">
                            </div>
                            <div class="nama-komponen">
                                <?php echo e(session()->get('edit-cases')->name); ?>

                            </div>
                        </div>
                        </td>
                        <td class="py-4"><?php echo e(session()->get('edit-cases')->formattedPrice); ?></td>
                        <td class="py-4 e-commerce">
                            <img src="<?php echo e(asset('images/keranjang/logo-tokped.png')); ?>" alt="">                   
                        </td>
                        <td class="py-4">
                            <form action="<?php echo e(route('hapusItemSimulasi','edit-cases')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit"><iconify-icon icon="material-symbols:close" width="24" height="24"></iconify-icon></button>
                            </form>
                        </td>
                    <?php else: ?>    
                        <td>
                            <div class="d-flex align-items-center komponen py-2">
                                <form action="<?php echo e(url('/simulasi-rakit-pc/addComponent/cases')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="selectedGpuId" value="<?php echo e(session('edit-gpus') ? session()->get('edit-gpus')->id : ''); ?>" >
                                    <button class="btn add" type="submit" <?php echo e(session('edit-gpus') ? '' : 'disabled'); ?>>
                                        + Add Item
                                    </button>
                                </form>
                            </div>
                        </td>
                        <td class="py-4"></td>
                        <td class="py-4"></td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th class="py-4 category">Power Supply</th>
                    <?php if(session('edit-power_supplies')): ?>
                        <td>
                        <div class="d-flex align-items-center komponen">
                            <div class="flex-shrink-0">
                                <img width="40px" src="<?php echo e(asset('storage/images/pc-components/psu/'. session()->get('edit-power_supplies')->image)); ?>" alt="...">
                            </div>
                            <div class="nama-komponen">
                                <?php echo e(session()->get('edit-power_supplies')->name); ?>

                            </div>
                        </div>
                        </td>
                        <td class="py-4"><?php echo e(session()->get('edit-power_supplies')->formattedPrice); ?></td>
                        <td class="py-4 e-commerce">
                            <img src="<?php echo e(asset('images/keranjang/logo-tokped.png')); ?>" alt="">                   
                        </td>
                        <td class="py-4">
                            <form action="<?php echo e(route('hapusItemSimulasi','edit-power_supplies')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit"><iconify-icon icon="material-symbols:close" width="24" height="24"></iconify-icon></button>
                            </form>
                        </td>
                    <?php else: ?>    
                        <td>
                            <div class="d-flex align-items-center komponen py-2">
                                <form action="<?php echo e(url('/simulasi-rakit-pc/addComponent/power_supplies')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="selectedCaseId" value="<?php echo e(session('edit-cases') ? session()->get('edit-cases')->id : ''); ?>" >
                                    <input type="hidden" name="totalWattage" value="<?php echo e($totalWattage); ?>">
                                    <button class="btn add" type="submit" <?php echo e(session('edit-cases') ? '' : 'disabled'); ?>>
                                        + Add Item
                                    </button>
                                </form>
                            </div>
                        </td>
                        <td class="py-4"></td>
                        <td class="py-4"></td>
                    <?php endif; ?>
                </tr>
            </tbody>
        </table>
    </section>

    <div class="container">
        <div class="d-flex justify-content-end">
            <h3>Total : </h3>
            <h3 class="ms-3"><b><?php echo e($formattedTotalPrice); ?></b></h3>
        </div>
        <div class="d-flex justify-content-end">
            <div class="me-3">
                <?php if(Auth::user()->id != $): ?>
                    <?php if(auth()->guard()->check()): ?>
                    <button class="btn add" data-bs-toggle="modal" data-bs-target="#saveModal">Simpan</button>
                    <?php else: ?>
                    <a class="btn add" href="<?php echo e(route('login')); ?>">Simpan</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <div class="pb-5" style="text-align: end;">
                <a class="btn tokopedia" href="#" role="button" onclick="<?php echo e($multipleUrlsScript); ?>"
                >Beli di Tokopedia</a>
            </div>
        </div>
    </div>

    <?php echo $__env->make('simulasi-rakit-pc._save-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://code.iconify.design/iconify-icon/1.0.2/iconify-icon.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\larasites\bycom\resources\views/rakitanku/detail-rakitanku.blade.php ENDPATH**/ ?>