
<?php $__env->startSection('main-content'); ?>
<div class="section-title komponen container mt-5">
  <h3 class="pt-3 pb-3">DAFTAR RAKITANKU</h3>
</div>

<section class="container d-flex justify-content-between mt-5 mb-5">
  <table class="table">
      <thead>
          <tr class="heading-table">
              <th scope="col">Kode Rakitan</th>
              <th scope="col">Judul Rakitan</th>
              <th scope="col">Total Harga</th>
              <th scope="col">Action</th>
          </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $listRakitan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rakitan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <tr>
            <th class="py-4 category"><?php echo e($rakitan->code); ?></th>
            <td class="py-4 nama-komponen rakitanku"><?php echo e($rakitan->name); ?></td>
            <td class="py-4"><?php echo e($rakitan->totalPrice); ?></td>
            <td class="py-4 btn-view"><a class="btn add view-details" href="<?php echo e(url('rakitanku/'.$rakitan->code)); ?>" role="button"> View</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
      </tbody>
  </table>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\larasites\bycom\resources\views/rakitanku/index.blade.php ENDPATH**/ ?>