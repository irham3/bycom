<div class="side-nav">
  <div class="container pt-5" style="padding-left: 50px;">
      <div class="kategori">
          <b>Kategori</b>
          <ul>
            <li class="nav-item <?php echo e((request()->is('marketplace')) ? 'active' : ''); ?>">
                <a href="<?php echo e(url('marketplace')); ?>">Lihat Semua</a>
            </li>
            <li class="nav-item <?php echo e((request()->is('marketplace/cpus')) ? 'active' : ''); ?>">
                <a href="<?php echo e(url('marketplace/cpus')); ?>">CPU</a>
            </li>
            <li class="nav-item <?php echo e((request()->is('marketplace/cases')) ? 'active' : ''); ?>">
                <a href="<?php echo e(url('marketplace/cases')); ?>">Casing PC</a>
            </li>
            <li class="nav-item <?php echo e((request()->is('marketplace/motherboards')) ? 'active' : ''); ?>">
                <a href="<?php echo e(url('marketplace/motherboards')); ?>">Motherboard</a>
            </li>
            <li class="nav-item <?php echo e((request()->is('marketplace/gpus')) ? 'active' : ''); ?>">
                <a href="<?php echo e(url('marketplace/gpus')); ?>">GPU</a>
            </li>
            <li class="nav-item <?php echo e((request()->is('marketplace/memories')) ? 'active' : ''); ?>">
                <a href="<?php echo e(url('marketplace/memories')); ?>">Memory</a>
            </li>
            <li class="nav-item <?php echo e((request()->is('marketplace/power_supplies')) ? 'active' : ''); ?>">
                <a href="<?php echo e(url('marketplace/power_supplies')); ?>">Power Supply (PSU)</a>
            </li>
            <li class="nav-item <?php echo e((request()->is('marketplace/internal_storages')) ? 'active' : ''); ?>">
                <a href="<?php echo e(url('marketplace/internal_storages')); ?>">Internal Storage</a>
            </li>
          </ul>
      </div>
      
  </div>
</div><?php /**PATH D:\larasites\bycom\resources\views/layouts/side-nav-marketplace.blade.php ENDPATH**/ ?>