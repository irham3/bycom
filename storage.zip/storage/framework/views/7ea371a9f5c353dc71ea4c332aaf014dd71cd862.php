<header>
    <a class="navbar-brand" href="<?php echo e(route('beranda')); ?>">
        <img src="<?php echo e(url('images/logo.png')); ?>" alt="Logo" class="d-inline-block align-text-top">
    </a>
    <nav class="navbar">
        <a href="<?php echo e(route('beranda')); ?>" class="<?php echo e((request()->is('/')) ? 'active' : ''); ?>">Beranda</a>
        <a href="<?php echo e(url('simulasi-rakit-pc')); ?>" class="<?php echo e((request()->is('simulasi-rakit-pc*')) ? 'active' : ''); ?>">Simulasi Rakit PC</a>
        <a href="<?php echo e(url('marketplace')); ?>" class="<?php echo e((request()->is('marketplace*')) ? 'active' : ''); ?>">Marketplace</a>
    </nav>
    <?php if(Route::has('login')): ?>
            <div class="d-flex icon-nav">
                <?php if(auth()->guard()->check()): ?>
                <div class="dropdown">
                    <a href="#" class="fas fa-user user-profile icons"id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false"></a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                        <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Profile</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('rakitanku')); ?>">Rakitanku</a></li>
                        <li>
                            <form action="<?php echo e(route('logout')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    this.closest('form').submit();">Logout</a>
                            </form>
                        </li>
                    </ul>
                </div>
                <?php else: ?>
                    <div class="menu login"><a href="<?php echo e(route('login')); ?>">Log In</a></div>
                    <div class="menu"><a href="<?php echo e(route('register')); ?>">Register</a></div>              
                <?php endif; ?>
            </div>
    <?php endif; ?> 
</header>
<!-- header section ends -->
<!-- home section starts  --><?php /**PATH D:\larasites\bycom\resources\views/layouts/header.blade.php ENDPATH**/ ?>