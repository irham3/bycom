<section class="footer bg-dark">

    <div class="box-container">

        <div class="footer-desc">
            <div class="logo-area">
                <img src="<?php echo e(url('images/logo.png')); ?>" alt="">
            </div>
            <div class="desc-area">
                <p>Membantu anda untuk merakit PC sesuai kebutuhan yang anda inginkan.</p>
            </div>
        </div>
        <div class="footer-desc">
            <div class="logo-area">
                <span class="logo-name">Lokasi Kami</span>
            </div>
            <div class="desc-area">
                <p>Jl. Telekomunikasi. 1, Terusan Buahbatu - Bojongsoang, Telkom University, Sukapura, Kec. Dayeuhkolot, Kabupaten Bandung, Jawa Barat 40257</p>
            </div>
        </div>
        <div class="footer-desc">
           <div class="logo-area">
                <span class="logo-name">Kontak Kami</span>
            </div>
            <div class="desc-area">
                <p><a href="#">bycom@gmail.com</a></p>
                <p><a href="#">+62 000-0000-0000</a></p>
            </div>
        </div>

        <div class="footer-desc">
            <div class="logo-area">
                <span class="logo-name"></span>
            </div>
            <div class="desc-area logo d-flex">
                <a class="icons" href="#"><img src="images/sosmed.png" alt=""></a>
                <a class="icons" href="#"><img src="images/sosmed-2.png" alt=""></a>
                <a class="icons" href="#"><img src="images/sosmed-3.png" alt=""></a>
                <a class="icons" href="#"><img src="images/sosmed-4.png" alt=""></a>
            </div>
        </div>

    </div>

    <div class="credit">Copyright® 2022 Kaizen Team All rights Reserved</div>

</section><?php /**PATH D:\larasites\bycom\resources\views/layouts/footer.blade.php ENDPATH**/ ?>